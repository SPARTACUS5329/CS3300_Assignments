docker --debug build -t cs3300_a3 .

docker run -it cs3300_a3 /bin/bash