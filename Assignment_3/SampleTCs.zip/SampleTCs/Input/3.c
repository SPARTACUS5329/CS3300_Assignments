#include<stdio.h>

int main() {
    int i;
    i = 0;
    while (i < 5) {
        printf("i = %d\n", i);
        i = i + 1;
    }
    return 0;
}